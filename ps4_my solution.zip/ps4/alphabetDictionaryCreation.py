

alphabetDict = {}
alphabetStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz "
for i in range(1,54):
    alphabetDict[i] = alphabetStr[i-1]






