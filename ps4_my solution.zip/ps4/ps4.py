# 6.00 Problem Set 4
#
# Caesar Cipher Skeleton
#
import string
import random

WORDLIST_FILENAME = "words.txt"
ALPHABET_STR_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
ALPHABET_STR_LOWER = ALPHABET_STR_UPPER.lower() + " "
ALPHABET_DICT_UPPER = {}
ALPHABET_DICT_LOWER = {}
for index in range(1,len(ALPHABET_STR_UPPER)+1):
    ALPHABET_DICT_UPPER[index] = ALPHABET_STR_UPPER[index-1]
for index in range(1,len(ALPHABET_STR_LOWER)+1):
    ALPHABET_DICT_LOWER[index] = ALPHABET_STR_LOWER[index-1]
UNAPPROVED_CHARACTERS = "!@#$%^&*()-_+={}[]|\:;'<>?,./\""

# -----------------------------------
# Helper code
# (you don't need to understand this helper code)
def load_words():
    print "Loading word list from file..."
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r', 0)
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print "  ", len(wordlist), "words loaded."
    return wordlist

wordlist = load_words()

def is_word(wordlist, word):
    word = word.lower()
    word = word.strip(' ' + UNAPPROVED_CHARACTERS)
    return word in wordlist

MAX_WORD_LENGTH = 0
for word in wordlist:
    if len(word) > MAX_WORD_LENGTH:
        MAX_WORD_LENGTH = len(word)
## maxWordLength = 13

def random_word(wordlist):
    return random.choice(wordlist)

def random_string(wordlist, n):
    return " ".join([random_word(wordlist) for _ in range(n)])

def random_scrambled(wordlist, n):
    s = random_string(wordlist, n) + " "
    shifts = [(i, random.randint(0, 26)) for i in range(len(s)) if s[i-1] == ' ']
    return apply_shifts(s, shifts)[:-1]

def get_fable_string():
    f = open("fable.txt", "r")
    fable = str(f.read())
    f.close()
    return fable

def build_coder(shift):
    coderUpper = {}
    for index in ALPHABET_DICT_UPPER:
        if index + shift <= len(ALPHABET_DICT_UPPER) and index + shift > 0:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift]
        elif index + shift > len(ALPHABET_DICT_UPPER) + 1:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift - (len(ALPHABET_DICT_UPPER) + 1)]
        elif index + shift == len(ALPHABET_DICT_UPPER) + 1 or index + shift == 0:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ' '
        else: #index + shift < 0
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift + (len(ALPHABET_DICT_UPPER) + 1)]
    coderLower = {}
    for index in ALPHABET_DICT_LOWER:
        if index + shift <= len(ALPHABET_DICT_LOWER) and index + shift > 0:
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift]
        elif index + shift > len(ALPHABET_DICT_LOWER):
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift - len(ALPHABET_DICT_LOWER)]
        else: #index + shift <= 0
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift + len(ALPHABET_DICT_LOWER)]
    for key in coderLower:
        coderUpper[key] = coderLower[key] #appends coderLower onto coderUpper
    return coderUpper

def build_encoder(shift):
    assert shift >= 0 and shift <= len(ALPHABET_STR_LOWER)
    return build_coder(shift)

def build_decoder(shift):
    assert shift >= 0 and shift <= len(ALPHABET_STR_LOWER)
    return build_coder(-shift)

def apply_coder(text, coder):
    codedText = ""
    for letter in text:
        if letter in UNAPPROVED_CHARACTERS:
            codedText += letter
        else:
            codedText += coder[letter]
    return codedText

def apply_shift(text, shift):
    return apply_coder(text, build_coder(shift))

def find_best_shift(wordlist, text):
    for shift in range(len(ALPHABET_STR_LOWER) + 1):
        shiftedText = apply_coder(text, build_decoder(shift))
        shiftedTextList = shiftedText.split(' ')
        areAllWords = True
        for word in shiftedTextList:
            if not is_word(wordlist, word):
                areAllWords = False
        if areAllWords == True:
            return shift
        
def apply_shifts(text, shifts):
    shiftedText = text
    for shift in shifts:
        shiftedText = shiftedText[0:shift[0]] + apply_shift(shiftedText[shift[0]:],shift[1])
    return shiftedText

def find_shift_with_space(wordlist, text, shiftPos, atEnd):
    print text
    for shift in range(len(ALPHABET_STR_LOWER) + 1):
        shiftedText = apply_shifts(text, [(shiftPos,shift)])
        shiftedTextList = shiftedText.split(' ')
        '''
        Loops to check whether:
            1. a. If the shifted text is within one character from the end
               b. All words from attempted shift are in wordlist
            2. a. The last list entry is a space
               b. The remaining list entries are in wordlist
        Returns shift tuple if (1a and 1b) or (2a and 2b) are met
        '''
        areAllWords = True
        if atEnd:
            for word in shiftedTextList:
                if not is_word(wordlist, word):
                    areAllWords = False
            if areAllWords:
                return shift
        
        if shiftedTextList[-1] != '':
            areAllWords = False
        for word in shiftedTextList[:-1]:
            if len(shiftedTextList) < 2:
                areAllWords = False
            if not is_word(wordlist, word):
                areAllWords = False
        if areAllWords == True:
            #print 'success'
            return shift
    return False

#[shift, endPos]
def find_best_shifts(wordlist, text):
    shiftList = [] #where list of shift tuples will be stored
    startList = [0] #where to start looking for shifts
    partiallyUnscrambledText = text #this will be modified as shifts are found
    fBSRResults = 1
    loopCount = 0
    while startList[-1] < len(text) - 2:# or fBSRResults == False: #If start >= len(text) - 1, then it has reached the end of the text
        if type(fBSRResults) != bool:
            fBSRResults = find_best_shifts_rec(wordlist, partiallyUnscrambledText, startList[-1], startList[-1] + 1)
            if type(fBSRResults) != bool:
                shiftList += [(startList[-1],fBSRResults[0])]
                partiallyUnscrambledText = apply_shifts(partiallyUnscrambledText, [shiftList[-1]])
                startList += [fBSRResults[1]]
        else:
            #delete last attempt and rerun starting check for words after the result of the last attempt (considered failure) (loop back if fails again)
            print 'shiftList before = ',shiftList
            print 'startList before = ',startList
            lastShift = shiftList[-1][0] #Saves position of last successful shift (used as new start point for length of word to fbs for)
            lastStart = startList[-1] #Saves position of last successful stop (used as new start point for length of word to fbs for)
            shiftList = delete_last_entry(shiftList)
            startList = delete_last_entry(startList)
            print 'shiftList after = ',shiftList
            print 'startList after = ',startList
            print 'lastStart = ',lastStart,'     lastShift = ',lastShift
            partiallyUnscrambledText = apply_shifts(text, shiftList)
            fBSRResults = find_best_shifts_rec(wordlist, partiallyUnscrambledText, lastShift, min(lastStart + 1, len(text)))
            #print fBSRResults
            if type(fBSRResults) != bool:
                shiftList += [(startList[-1],fBSRResults[0])]
                partiallyUnscrambledText = apply_shifts(partiallyUnscrambledText, [shiftList[-1]])
                startList += [fBSRResults[1]]
                #print shiftList
        if startList[-1] >= len(text) - 2:
            return shiftList
        
def delete_last_entry(listToModify):
    newList = []
    for entry in listToModify:
        if entry != listToModify[-1]:
            newList += [entry]
    return newList

def find_best_shifts_rec(wordlist, entireText, shiftPos, textPosStart): #_custom_shift_start
    for textPos in range(textPosStart, min(textPosStart + MAX_WORD_LENGTH, len(entireText))):
        fBSResult = find_shift_with_space(wordlist, entireText[:textPos], shiftPos, textPos >= len(entireText) - 1)
        if type(fBSResult) != bool:
            return [fBSResult, textPos] #[shift, endPos] NOTE: shiftPos is endPos from 
    return False
    
def wtfable():
    scramText = get_fable_string()
    bestShifts = find_best_shifts(wordlist, scramText)
    print 'Encrypted text is: '
    print '  ',scramText
    print 'Decrypted text is: '
    print '  ',apply_shifts(scramText, bestShifts)
    print 'Decryption shifts are: '
    print '  ',bestShifts
    #                       1         2         3         4         5         6         7         8         9         10
def test_fbs():  #012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901
    text2scram = "Here is a longer test string to see how well this program works, and how it handles symbols at the end."
    scramText = apply_shifts(text2scram, [(0, 18), (5, 16), (8, 2), (10,6), (17,5), (22,16), (32,6), \
                                          (36,1), (40,25), (45,13), (50,6), (58,7), (65,3), (69,16), \
                                          (73,11), (76,2), (84,20), (92,6), (95,17), (99,6)])
    #scramText = 'Zwccfrzovlzgoanfe?'
    bestShifts = find_best_shifts(wordlist, scramText)
    print 'Encrypted text is: '
    print '  ',scramText
    print 'Decrypted text is: '
    print '  ',apply_shifts(scramText, bestShifts)
    print 'Decryption shifts are: '
    print '  ',bestShifts
    



    
