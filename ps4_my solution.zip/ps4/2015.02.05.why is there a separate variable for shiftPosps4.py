# 6.00 Problem Set 4
#
# Caesar Cipher Skeleton
#
import string
import random

WORDLIST_FILENAME = "words.txt"
ALPHABET_STR_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
ALPHABET_STR_LOWER = ALPHABET_STR_UPPER.lower() + " "
ALPHABET_DICT_UPPER = {}
ALPHABET_DICT_LOWER = {}
for index in range(1,len(ALPHABET_STR_UPPER)+1):
    ALPHABET_DICT_UPPER[index] = ALPHABET_STR_UPPER[index-1]
for index in range(1,len(ALPHABET_STR_LOWER)+1):
    ALPHABET_DICT_LOWER[index] = ALPHABET_STR_LOWER[index-1]
UNAPPROVED_CHARACTERS = "!@#$%^&*()-_+={}[]|\:;'<>?,./\""

# -----------------------------------
# Helper code
# (you don't need to understand this helper code)
def load_words():
    print "Loading word list from file..."
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r', 0)
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print "  ", len(wordlist), "words loaded."
    return wordlist

wordlist = load_words()

def is_word(wordlist, word):
    word = word.lower()
    word = word.strip(' ' + UNAPPROVED_CHARACTERS)
    return word in wordlist

MAX_WORD_LENGTH = 0
for word in wordlist:
    if len(word) > MAX_WORD_LENGTH:
        MAX_WORD_LENGTH = len(word)
## maxWordLength = 13

def random_word(wordlist):
    return random.choice(wordlist)

def random_string(wordlist, n):
    return " ".join([random_word(wordlist) for _ in range(n)])

def random_scrambled(wordlist, n):
    s = random_string(wordlist, n) + " "
    shifts = [(i, random.randint(0, 26)) for i in range(len(s)) if s[i-1] == ' ']
    return apply_shifts(s, shifts)[:-1]

def get_fable_string():
    f = open("fable.txt", "r")
    fable = str(f.read())
    f.close()
    return fable

def build_coder(shift):
    coderUpper = {}
    for index in ALPHABET_DICT_UPPER:
        if index + shift <= len(ALPHABET_DICT_UPPER) and index + shift > 0:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift]
        elif index + shift > len(ALPHABET_DICT_UPPER) + 1:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift - (len(ALPHABET_DICT_UPPER) + 1)]
        elif index + shift == len(ALPHABET_DICT_UPPER) + 1 or index + shift == 0:
            coderUpper[ALPHABET_DICT_UPPER[index]] = ' '
        else: #index + shift < 0
            coderUpper[ALPHABET_DICT_UPPER[index]] = ALPHABET_DICT_UPPER[index + shift + (len(ALPHABET_DICT_UPPER) + 1)]
    coderLower = {}
    for index in ALPHABET_DICT_LOWER:
        if index + shift <= len(ALPHABET_DICT_LOWER) and index + shift > 0:
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift]
        elif index + shift > len(ALPHABET_DICT_LOWER):
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift - len(ALPHABET_DICT_LOWER)]
        else: #index + shift <= 0
            coderLower[ALPHABET_DICT_LOWER[index]] = ALPHABET_DICT_LOWER[index + shift + len(ALPHABET_DICT_LOWER)]
    for key in coderLower:
        coderUpper[key] = coderLower[key] #appends coderLower onto coderUpper
    return coderUpper

def build_encoder(shift):
    assert shift >= 0 and shift <= len(ALPHABET_STR_LOWER)
    return build_coder(shift)

def build_decoder(shift):
    assert shift >= 0 and shift <= len(ALPHABET_STR_LOWER)
    return build_coder(-shift)

def apply_coder(text, coder):
    codedText = ""
    for letter in text:
        if letter in UNAPPROVED_CHARACTERS:
            codedText += letter
        else:
            codedText += coder[letter]
    return codedText

def apply_shift(text, shift):
    return apply_coder(text, build_coder(shift))

def find_best_shift(wordlist, text):
    for shift in range(len(ALPHABET_STR_LOWER) + 1):
        shiftedText = apply_coder(text, build_decoder(shift))
        shiftedTextList = shiftedText.split(' ')
        areAllWords = True
        for word in shiftedTextList:
            if not is_word(wordlist, word):
                areAllWords = False
        if areAllWords == True:
            return shift
        
def apply_shifts(text, shifts):
    shiftedText = text
    for shift in shifts:
        shiftedText = shiftedText[0:shift[0]] + apply_shift(shiftedText[shift[0]:],shift[1])
    return shiftedText

def find_best_shift_with_position_and_space(wordlist, text, start, atEnd):
    print text
    for shiftPos in range(start, len(text)):
        for shift in range(len(ALPHABET_STR_LOWER) + 1):
            shiftedText = apply_shifts(text, [(shiftPos,shift)])
            shiftedTextList = shiftedText.split(' ')
            '''
            Loops to check whether:
                1. a. If the shifted text is within one character from the end
                   b. All words from attempted shift are in wordlist
                2. a. The last list entry is a space
                   b. The remaining list entries are in wordlist
            Returns shift tuple if (1a and 1b) or (2a and 2b) are met
            '''
            areAllWords = True
            if atEnd:
                for word in shiftedTextList:
                    if not is_word(wordlist, word):
                        areAllWords = False
                if areAllWords:
                    return (shiftPos, shift)
                
            if shiftedTextList[-1] != '':
                areAllWords = False
            for word in shiftedTextList[:-1]:
                if len(shiftedTextList) < 2:
                    areAllWords = False
                if not is_word(wordlist, word):
                    areAllWords = False
            if areAllWords == True:
                print shiftedTextList, ' ',shiftedText
                print shiftedText
                return (shiftPos, shift)
    return False

def find_best_shifts(wordlist, text):
    shiftList = [(0,0)] #where list of shift tuples will go, ex: [(0,4),(5,9)]
    startList = [1] #where to start looking for shifts
    partiallyUnscrambledText = text #this will be modified as shifts are found
    fBSRResults = find_best_shifts_rec(wordlist, partiallyUnscrambledText, startList[-1], startList[-1])
    shiftList += [fBSRResults[0]]
    partiallyUnscrambledText = apply_shifts(partiallyUnscrambledText, [shiftList[-1]])
    startList += [fBSRResults[1]]
    while startList[-1] < len(text) - 1:# or fBSRResults == False: #If start >= len(text) - 1, then it has reached the end of the text
        if fBSRResults != False:
            fBSRResults = find_best_shifts_rec(wordlist, partiallyUnscrambledText, startList[-1], startList[-1])
            if fBSRResults != False:
                shiftList += [fBSRResults[0]]
                partiallyUnscrambledText = apply_shifts(partiallyUnscrambledText, [shiftList[-1]])
                startList += [fBSRResults[1]]
        else:
            #delete last attempt and rerun starting check for words after the result of the last attempt (considered failure) (loop back if fails again)
            lastShift = shiftList[-1][0] #Saves position of last successful shift (used as new start point for length of word to fbs for)
            lastStart = startList[-1] #Saves position of last successful stop (used as new start point for length of word to fbs for)
            shiftList = delete_last_entry(shiftList)
            startList = delete_last_entry(startList)
            #print 'lastStart = ',lastStart,'     lastShift = ',lastShift
            partiallyUnscrambledText = apply_shifts(text, shiftList)
            fBSRResults = find_best_shifts_rec(wordlist, partiallyUnscrambledText, shiftList[-1][0], min(lastStart - 1, len(text)))
            if fBSRResults != False:
                shiftList += [fBSRResults[0]]
                partiallyUnscrambledText = apply_shifts(partiallyUnscrambledText, [shiftList[-1]])
                startList += [fBSRResults[1]]
            
    return shiftList
        
def delete_last_entry(listToModify):
    newList = []
    for entry in listToModify:
        if entry != listToModify[-1]:
            newList += [entry]
    return newList

'''def find_best_shifts_rec(wordlist, entireText, startShifting):
    for stringPos in range(startShifting, min(startShifting + MAX_WORD_LENGTH, len(entireText))):
        #print stringPos
        fBSResult = find_best_shift_with_position_and_space(wordlist, entireText[:stringPos], startShifting, stringPos == len(entireText) - 1)
        if fBSResult != False:
            return [fBSResult, stringPos]
    return False #Cannot find a valid shift for length = longest word length, therefore, a previous shift was incorrect'''
''' REMOVE ORIGINAL '''
def find_best_shifts_rec(wordlist, entireText, startShiftPos, textLengthStart): #_custom_shift_start
    for stringPos in range(textLengthStart, min(textLengthStart + MAX_WORD_LENGTH, len(entireText) - 1)):
        ''' *** '''
        fBSResult = find_best_shift_with_position_and_space(wordlist, entireText[:stringPos], startShiftPos, stringPos == len(entireText) - 1)
        if fBSResult != False:
            return [fBSResult, stringPos]
    return False
    
def wtfable():
    bestShifts = find_best_shifts(wordlist, get_fable_string())
    print bestShifts
    
def test_fbs():
    text2scram = "Hello shoes boats people?"
    scramText = apply_shifts(text2scram, [(0, 18), (6, 16) , (12, 2), (18,6)])
    #scramText = 'Zwccfrzovlzgoanfe?'
    bestShifts = find_best_shifts(wordlist, scramText)
    print bestShifts



    
