# 6.00 Problem Set 3
# 
# Hangman
#


# -----------------------------------
# Helper code
# (you don't need to understand this helper code)
import random
import string

WORDLIST_FILENAME = "words.txt"

def load_words():
    """
    Returns a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print "Loading word list from file..."
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r', 0)
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = string.split(line)
    print "  ", len(wordlist), "words loaded."
    return wordlist

def choose_word(wordlist):
    """
    wordlist (list): list of words (strings)

    Returns a word from wordlist at random
    """
    return random.choice(wordlist)

# end of helper code
# -----------------------------------

# actually load the dictionary of words and point to it with 
# the wordlist variable so that it can be accessed from anywhere
# in the program
wordlist = load_words()

# your code begins here!
def hangman():
    """
    Start up and carry out an interactive
    Hangman game between a player and a
    computer
    """

    ##Global constant initialization
    hangmanWord = choose_word(wordlist)
    wordSolved = False
    unsolvedWord = ""
    for letter in hangmanWord:
        unsolvedWord += "_"
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    availableLetters = alphabet
    remainingGuesses = 7
    ##Intro text 
    print "Welcome to the game, Hangman!"
    print "I am thinking of a word that is",len(hangmanWord),"letters long."
    print "-------------"


##CHECKS IF LETTER IS IN A STRING OF LETTERS
    def checkLetterIsInString(letter,stringOfLetters):
        isLetterInString = False
        for indLetter in stringOfLetters:
            if letter == indLetter:
                isLetterInString = True
        return isLetterInString

##CHECKS IF INPUTTED VALUE IS A CHARACTER
    def checkInputIsLetter(inputtedValue):
        if type(inputtedValue) == str and len(inputtedValue) == 1:
            return checkLetterIsInString(inputtedValue,alphabet)
        else:
            return False

##REMOVES A LETTER FROM A LIST OF LETTERS GIVEN
    def removeLetterFromAvailable(letter,availableLetters):
        newAvailableLetters = ""
        for indChar in availableLetters:
            if letter != indChar:
                newAvailableLetters += indChar
        return newAvailableLetters

##REPLACES APPROPRIATE " _" WITH "LETTER"
    def replaceSpaceUnsolved(letter,word,unsolvedWord):
        charPos = -1
        newUnsolvedWord = ""
        for indLetter in word:
            charPos += 1
            if indLetter == letter:
                newUnsolvedWord += letter
            else:
                newUnsolvedWord += unsolvedWord[charPos]
        return newUnsolvedWord

##ADDS SPACES BETWEEN UNDERSCORES, WRITES LETTERS IN UPPERCASE
    def splitWord(word):
        wordWithSpaces = ""
        for letter in word:
            if letter == "_":
                wordWithSpaces += " "
            wordWithSpaces += letter.upper()
        return wordWithSpaces
    
    while (not wordSolved) and (remainingGuesses > 0):
        print "You have",remainingGuesses,"guesses left."
        print "Available letters:",availableLetters
        guess = raw_input(["Please guess a letter:"]).lower()
        if (not checkInputIsLetter(guess)):
            print "Sorry, I didn't quite get that."
            ##Restart Loop
        else:
            if not checkLetterIsInString(guess,availableLetters):
                print "Sorry, that letter has already been guessed."
                ##Restart Loop
            else:
                availableLetters = removeLetterFromAvailable(guess,availableLetters)
                if not checkLetterIsInString(guess,hangmanWord):
                    print "Oops! That letter is not in my word:",splitWord(unsolvedWord)
                    remainingGuesses -= 1
                else:
                    unsolvedWord = replaceSpaceUnsolved(guess,hangmanWord,unsolvedWord)
                    print "Good guess:",splitWord(unsolvedWord)
                    if unsolvedWord == hangmanWord:
                        wordSolved = True
                print "-------------"

    if wordSolved:
        print "Congratulations, you won!"
    if remainingGuesses == 0:
        print "Sorry, you lose... The word was:",hangmanWord
        












