
def evaluate_poly(poly, x):
    ##Check validity of inputs
    assert type(x) == float or type(x) == int
    assert type(poly) == list or type(poly) == tuple
    for coeff in poly:
        assert type(coeff) == float or type(coeff) == int
    assert len(poly) > 0
    ##Evaluate value of polynomial (represented by tuple 'poly') at x
    evaluatedValue = 0
    index = -1
    for coeff in poly:
        index += 1
        evaluatedValue += coeff*pow(x, index)
    return float(evaluatedValue)

def compute_deriv(poly):
    ##Check validity of inputs
    assert type(poly) == list or type(poly) == tuple
    for coeff in poly:
        assert type(coeff) == float or type(coeff) == int
    assert len(poly) > 0
    ##Evaluate value of polynomial (represented by tuple 'poly') at x
    polyDerivative = ()
    index = -1
    for coeff in poly:
        index += 1
        if index > 0:
            polyDerivative += (coeff*index,)
    return polyDerivative

def withinAllowableError(result, target, allowableError):
    return abs(result - target) <= allowableError

def compute_root(poly, x_0, epsilon):
    iterations = 0
    while not withinAllowableError(evaluate_poly(poly, x_0), 0, epsilon):
        x_0 = x_0 - evaluate_poly(poly, x_0) / evaluate_poly(compute_deriv(poly),x_0)
        fx_0 = evaluate_poly(poly, x_0)
        iterations += 1
    return (x_0,iterations)


        




