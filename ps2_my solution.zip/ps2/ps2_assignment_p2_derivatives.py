

def compute_deriv(poly):
    ##Check validity of inputs
    assert type(poly) == list or type(poly) == tuple
    for coeff in poly:
        assert type(coeff) == float or type(coeff) == int
    assert len(poly) > 0
    ##Evaluate value of polynomial (represented by tuple 'poly') at x
    polyDerivative = ()
    index = -1
    for coeff in poly:
        index += 1
        if index > 0:
            polyDerivative += (coeff*index,)
    return polyDerivative




