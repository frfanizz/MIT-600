

def evaluate_poly(poly, x):
    ##Check validity of inputs
    assert type(poly) == list or type(poly) == tuple
    assert type(x) == float or type(x) == int
    for coeff in poly:
        assert type(coeff) == float or type(coeff) == int
    assert len(poly) > 0
    ##Evaluate value of polynomial (represented by tuple 'poly') at x
    evaluatedValue = 0
    index = -1
    for coeff in poly:
        index += 1
        evaluatedValue += coeff*pow(x, index)
    return float(evaluatedValue)




