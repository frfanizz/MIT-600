# 6.00 Problem Set 8
#
# Name:
# Collaborators:
# Time:



import numpy
import random
import pylab
from ps7 import *

def capFirstChar(stringToCapitalize):
    return stringToCapitalize[0].upper() + stringToCapitalize[1:]
#
# PROBLEM 1
#
class ResistantVirus(SimpleVirus):
    """
    Representation of a virus which can have drug resistance.
    """      
    def __init__(self, maxBirthProb, clearProb, resistances, mutProb):
        """
        Initialize a ResistantVirus instance, saves all parameters as attributes
        of the instance.

        maxBirthProb: Maximum reproduction probability (a float between 0-1)        
        clearProb: Maximum clearance probability (a float between 0-1).

        resistances: A dictionary of drug names (strings) mapping to the state
        of this virus particle's resistance (either True or False) to each drug.
        e.g. {'guttagonol':False, 'grimpex',False}, means that this virus
        particle is resistant to neither guttagonol nor grimpex.

        mutProb: Mutation probability for this virus particle (a float). This is
        the probability of the offspring acquiring or losing resistance to a drug.        
        """
        # TODO
        self.maxBirthProb = maxBirthProb
        self.clearProb = clearProb
        self.resistances = resistances
        self.mutProb = mutProb
        
        
    def isResistantTo(self, drug):
        """
        Get the state of this virus particle's resistance to a drug. This method
        is called by getResistPop() in Patient to determine how many virus
        particles have resistance to a drug.    

        drug: The drug (a string)
        returns: True if this virus instance is resistant to the drug, False
        otherwise.
        """
        # TODO
        if drug in self.resistances:
            return self.resistances[drug]
        else:
            return False
        

    def reproduce(self, popDensity, activeDrugs):
        """
        Stochastically determines whether this virus particle reproduces at a
        time step. Called by the update() method in the Patient class.

        If the virus particle is not resistant to any drug in activeDrugs,
        then it does not reproduce. Otherwise, the virus particle reproduces
        with probability:
        
        self.maxBirthProb * (1 - popDensity).                       
        
        If this virus particle reproduces, then reproduce() creates and returns
        the instance of the offspring ResistantVirus (which has the same
        maxBirthProb and clearProb values as its parent). 

        For each drug resistance trait of the virus (i.e. each key of
        self.resistances), the offspring has probability 1-mutProb of
        inheriting that resistance trait from the parent, and probability
        mutProb of switching that resistance trait in the offspring.        

        For example, if a virus particle is resistant to guttagonol but not
        grimpex, and `self.mutProb` is 0.1, then there is a 10% chance that
        that the offspring will lose resistance to guttagonol and a 90% 
        chance that the offspring will be resistant to guttagonol.
        There is also a 10% chance that the offspring will gain resistance to
        grimpex and a 90% chance that the offspring will not be resistant to
        grimpex.

        popDensity: the population density (a float), defined as the current
        virus population divided by the maximum population        

        activeDrugs: a list of the drug names acting on this virus particle
        (a list of strings). 
        
        returns: a new instance of the ResistantVirus class representing the
        offspring of this virus particle. The child should have the same
        maxBirthProb and clearProb values as this virus. Raises a
        NoChildException if this virus particle does not reproduce.         
        """
        # TODO
        immuneToDrugs = True
        for drug in activeDrugs:
            if not self.isResistantTo(drug):
                immuneToDrugs = False
                #assumes virus must be resistant to all drugs to reproduce
        childResistances = {}
        if immuneToDrugs and random.random() <= self.maxBirthProb * (1 - popDensity):
            for drug in self.resistances:
                childResistances[drug] = self.resistances[drug]
                if random.random() <= self.mutProb: #switches resistance status
                    childResistances[drug] = not childResistances[drug]
            return ResistantVirus(self.maxBirthProb, self.clearProb, childResistances, self.mutProb)
        else:
            raise NoChildException()
            

class Patient(SimplePatient):
    """
    Representation of a patient. The patient is able to take drugs and his/her
    virus population can acquire resistance to the drugs he/she takes.
    """
    def __init__(self, viruses, maxPop):
        """
        Initialization function, saves the viruses and maxPop parameters as
        attributes. Also initializes the list of drugs being administered
        (which should initially include no drugs).               

        viruses: the list representing the virus population (a list of
        SimpleVirus instances)
        
        maxPop: the  maximum virus population for this patient (an integer)
        """
        # TODO
        SimplePatient.__init__(self, viruses, maxPop)
        self.prescriptions = []

    def addPrescription(self, newDrug):
        """
        Administer a drug to this patient. After a prescription is added, the 
        drug acts on the virus population for all subsequent time steps. If the
        newDrug is already prescribed to this patient, the method has no effect.

        newDrug: The name of the drug to administer to the patient (a string).

        postcondition: list of drugs being administered to a patient is updated
        """
        # TODO
        # should not allow one drug being added to the list multiple times
        isInList = False
        for prescription in self.prescriptions:
            if newDrug == prescription:
                isInList = True
        if not isInList:
            self.prescriptions.append(newDrug)

    def getPrescriptions(self):
        """
        Returns the drugs that are being administered to this patient.
        returns: The list of drug names (strings) being administered to this
        patient.
        """
        # TODO
        return self.prescriptions

    def getResistPop(self, drugResist):
        """
        Get the population of virus particles resistant to the drugs listed in 
        drugResist.        

        drugResist: Which drug resistances to include in the population (a list
        of strings - e.g. ['guttagonol'] or ['guttagonol', 'grimpex'])

        returns: the population of viruses (an integer) with resistances to all
        drugs in the drugResist list.
        """
        # TODO
        resistPop = 0
        for virus in self.viruses:
            resistantToAll = True
            for drug in drugResist:
                if not virus.isResistantTo(drug):
                    resistantToAll = False
            if resistantToAll:
                resistPop += 1
        return resistPop

    def update(self):
        """
        Update the state of the virus population in this patient for a single
        time step. update() should execute these actions in order:
        
        - Determine whether each virus particle survives and update the list of 
          virus particles accordingly          
        - The current population density is calculated. This population density
          value is used until the next call to update().
        - Determine whether each virus particle should reproduce and add
          offspring virus particles to the list of viruses in this patient. 
          The list of drugs being administered should be accounted for in the
          determination of whether each virus particle reproduces. 

        returns: the total virus population at the end of the update (an
        integer)
        """
        # TODO
        for virus in self.viruses:
            if virus.doesClear():
                self.viruses.remove(virus)
        currentPop = self.getTotalPop()
        newViruses = []
        for virus in self.viruses:
            try:
                newViruses.append(virus.reproduce(float(currentPop)/self.maxPop,\
                                                  self.prescriptions))
            except NoChildException:
                pass
        for newVirus in newViruses:
            self.viruses.append(newVirus)
        return self.getTotalPop()


def sim_patient_no_drugs(numVirus, maxBirthProb, clearProb, resistances, mutProb, maxPop):
    viruses = []
    for num in range(numVirus):
        viruses.append(ResistantVirus(maxBirthProb, clearProb, resistances, mutProb))
    return Patient(viruses, maxPop)

'''
FUTURE GOALS:
CREATE (2) FUNCTIONS TO CREATE HIST PLOTS AND AVG PLOTS FOR CUSTOM INPUTS OF ALL
VIRUS AND PATIENT VARIABLES. LET DRUGS BE ADMINISTERED THROUGH USE OF A LIST OF
TUPLES (TIMESTEP(S) AT WHICH THE DRUGS ARE ADMINISTERED, DRUGS ADMINISTERED)
(  EX: [(0, ['DRUG1']),([50,100,150],['DRUG2','DRUG3']),(150,[])]  )
RETURN APPROPRIATE DATA TO CREATE EACH TYPE OF PLOT
'''
#
# PROBLEM 2
#
def simulationWithDrug():
    """
    Runs simulations and plots graphs for problem 4.
    Instantiates a patient, runs a simulation for 150 timesteps, adds
    guttagonol, and runs the simulation for an additional 150 timesteps.
    total virus population vs. time and guttagonol-resistant virus population
    vs. time are plotted
    """
    # TODO
    #Virus/Pat constants---
    drug1 = 'guttagonol'
    maxBirthProb = 0.1
    clearProb = 0.05
    resistances = {drug1:False}
    mutProb = 0.005
    numVirus = 100
    maxPop = 1000
    timeStepsPart1 = 150
    prescriptionAdded = [drug1]
    timeStepsPart2 = 150
    #----------------------
    #Plot variables---
    simData = []
    numTrials = 5
    #-----------------
    #Running simulation numTrial # of times
    for trial in range(numTrials):
        withDrugPat = sim_patient_no_drugs(numVirus, maxBirthProb, clearProb,\
                                           resistances, mutProb, maxPop)
        simData.append([[numVirus],[withDrugPat.getResistPop(prescriptionAdded)]])
        for timeStep in range(timeStepsPart1):
            withDrugPat.update()
            simData[trial][0].append(withDrugPat.getTotalPop())
            simData[trial][1].append(withDrugPat.getResistPop(prescriptionAdded))
        for drug in prescriptionAdded:
            withDrugPat.addPrescription(drug)
        for timeStep in range(timeStepsPart2):
            withDrugPat.update()
            simData[trial][0].append(withDrugPat.getTotalPop())
            simData[trial][1].append(withDrugPat.getResistPop(prescriptionAdded))
    #take average of trials:
    plotData = []
    for popCountIndex in range(len(simData[0])):
        plotData.append([])
    for dataPoint in range(len(simData[0][0])):
        for popCountIndex in range(len(simData[0])):
            plotDataSum = 0
            for trial in range(numTrials):
                plotDataSum += simData[trial][popCountIndex][dataPoint]
            plotData[popCountIndex].append(plotDataSum / float(numTrials))
    #Plot 1 - Avg Pop after treatment
    pylab.plot(range(len(plotData[0])), plotData[0], label = 'Total Population')
    pylab.plot(range(len(plotData[0])), plotData[1],\
               label = capFirstChar(drug1) + '-Resistant Population')
    pylab.legend(loc='best')
    pylab.xlabel('Time Steps')
    pylab.ylabel('Number of Viruses')
    pylab.title('Simulation of Population of Viruses in Patient With \
Drug Treatment after '+str(timeStepsPart1)+' Time Steps')
    pylab.show()

#
# PROBLEM 3
#        

def simulationDelayedTreatment():
    """
    Runs simulations and make histograms for problem 5.
    Runs multiple simulations to show the relationship between delayed treatment
    and patient outcome.
    Histograms of final total virus populations are displayed for delays of 300,
    150, 75, 0 timesteps (followed by an additional 150 timesteps of
    simulation).    
    """
    # TODO
    #Virus/Pat constants---
    drug1 = 'guttagonol'
    maxBirthProb = 0.1
    clearProb = 0.05
    resistances = {drug1:False}
    mutProb = 0.005
    numVirus = 100
    maxPop = 1000
    timeStepLengthPart1 = [300,150,75,0]
    prescriptionAdded = [drug1]
    timeStepsPart2 = 150
    #----------------------
    #Plot variables---
    plotData = []
    for val in timeStepLengthPart1:
        plotData.append([])
    numTrials = 30
    #-----------------
    #Running simulation numTrial # of times
    timeStepIndex = 0
    for timeStepsPart1 in timeStepLengthPart1:
        for trial in range(numTrials):
            withDrugPat = sim_patient_no_drugs(numVirus, maxBirthProb, clearProb,\
                                           resistances, mutProb, maxPop)
            for timeStep in range(timeStepsPart1):
                withDrugPat.update()
            for drug in prescriptionAdded:
                withDrugPat.addPrescription(drug)
            for timeStep in range(timeStepsPart2):
                withDrugPat.update()
            plotData[timeStepIndex].append(withDrugPat.getTotalPop())
        timeStepIndex += 1
    #Create Histograms:
    labels = []
    for timeStepLength1 in timeStepLengthPart1:
        labels.append('Drug administered after ' + str(timeStepLength1) +\
                      ' time steps')
    pylab.figure()
    n, bins, patches = pylab.hist(plotData, 20, histtype='bar', label = labels)
    pylab.xlabel('Final Virus Population')
    pylab.ylabel('Number of Simulated Patients')
    pylab.title('Simulation of Viruses Population in ' + str(numTrials) + \
                ' Patients With Drug Treatment at Varying Times')
    pylab.legend(loc='best')
    pylab.show()


#
# PROBLEM 4
#
def simulationTwoDrugsDelayedTreatment():
    """
    Runs simulations and make histograms for problem 6.
    Runs multiple simulations to show the relationship between administration
    of multiple drugs and patient outcome.
   
    Histograms of final total virus populations are displayed for lag times of
    150, 75, 0 timesteps between adding drugs (followed by an additional 150
    timesteps of simulation).
    """
    # TODO
    #Virus/Pat constants---
    drug1 = 'guttagonol'
    drug2 = 'grimpex'
    maxBirthProb = 0.1
    clearProb = 0.05
    resistances = {drug1:False, drug2:False}
    mutProb = 0.005
    numVirus = 100
    maxPop = 1000
    timeStepsPart1 = 150
    prescriptionAddedPart1 = [drug1]
    timeStepLengthPart2 = [300,150,75,0]
    prescriptionAddedPart2 = [drug2]
    timeStepsPart3 = 150
    #----------------------
    #Plot variables---
    plotData = []
    for val in timeStepLengthPart2:
        plotData.append([])
    numTrials = 30
    #-----------------
    #Running simulation numTrial # of times
    timeStepIndex = 0
    for timeStepsPart2 in timeStepLengthPart2:
        for trial in range(numTrials):
            withDrugPat = sim_patient_no_drugs(numVirus, maxBirthProb, clearProb,\
                                           resistances, mutProb, maxPop)
            for timeStep in range(timeStepsPart1):
                withDrugPat.update()
            for drug in prescriptionAddedPart1:
                withDrugPat.addPrescription(drug)
            for timeStep in range(timeStepsPart2):
                withDrugPat.update()
            for drug in prescriptionAddedPart2:
                withDrugPat.addPrescription(drug)
            for timeStep in range(timeStepsPart3):
                withDrugPat.update()
            plotData[timeStepIndex].append(withDrugPat.getTotalPop())
        timeStepIndex += 1
    #Create Histograms:
    labels = []
    for timeStepLength2 in timeStepLengthPart2:
        labels.append('2nd drug administered after ' + str(timeStepLength2) +\
                      ' time steps')
    pylab.figure()
    n, bins, patches = pylab.hist(plotData, 20, histtype='bar', label = labels)
    pylab.xlabel('Final Virus Population')
    pylab.ylabel('Number of Simulated Patients')
    pylab.title('Simulation of Viruses Population in ' + str(numTrials) + \
                ' Patients With Drug Treatment at Varying Times')
    pylab.legend(loc='best')
    pylab.show()

#
# PROBLEM 5
#
def simulationTwoDrugsVirusPopulations():
    """
    Run simulations and plot graphs examining the relationship between
    administration of multiple drugs and patient outcome.
    Plots of total and drug-resistant viruses vs. time are made for a
    simulation with a 300 time step delay between administering the 2 drugs and
    a simulations for which drugs are administered simultaneously.        
    """
    #TODO
    #Virus/Pat constants---
    drug1 = 'guttagonol'
    drug2 = 'grimpex'
    maxBirthProb = 0.1
    clearProb = 0.05
    resistances = {drug1:False, drug2:False}
    mutProb = 0.005
    numVirus = 100
    maxPop = 1000
    timeStepsPart1 = 150
    prescriptionAddedPart1 = [drug1]
    timeStepLengthPart2 = [300,0]
    prescriptionAddedPart2 = [drug2]
    timeStepsPart3 = 150
    #----------------------
    #Plot variables---
    simData = []
    for timeStepsPart2Index in range(len(timeStepLengthPart2)):
        simData.append([])
    numTrials = 10
    #-----------------
    #Running simulation numTrial # of times
    def simDataCollect(timeStepsIndex, trial):
        withDrugPat.update()
        simData[timeStepsIndex][trial][0].append(withDrugPat.getTotalPop())
        simData[timeStepsIndex][trial][1].append(withDrugPat.getResistPop(prescriptionAddedPart1))
        simData[timeStepsIndex][trial][2].append(withDrugPat.getResistPop(prescriptionAddedPart2))
        simData[timeStepsIndex][trial][3].append(withDrugPat.getResistPop(prescriptionAddedPart1 + \
                                                                           prescriptionAddedPart2))
    for timeStepsIndex in range(len(timeStepLengthPart2)):
        for trial in range(numTrials):
            withDrugPat = sim_patient_no_drugs(numVirus, maxBirthProb, clearProb,\
                                           resistances, mutProb, maxPop)
            simData[timeStepsIndex].append([[numVirus],\
                            [withDrugPat.getResistPop(prescriptionAddedPart1)],\
                            [withDrugPat.getResistPop(prescriptionAddedPart2)],\
                            [withDrugPat.getResistPop(prescriptionAddedPart1 + \
                                                       prescriptionAddedPart2)]])
            for timeStep in range(timeStepsPart1):
                simDataCollect(timeStepsIndex, trial)
            for drug in prescriptionAddedPart1:
                withDrugPat.addPrescription(drug)
            for timeStep in range(timeStepLengthPart2[timeStepsIndex]):
                simDataCollect(timeStepsIndex, trial)
            for drug in prescriptionAddedPart2:
                withDrugPat.addPrescription(drug)
            for timeStep in range(timeStepsPart3):
                simDataCollect(timeStepsIndex, trial)
        timeStepsIndex += 1
    #take average of trials:
    plotData = []
    for timeStepsPart2Index in range(len(timeStepLengthPart2)):
        plotData.append([])
        for popCountIndex in range(len(simData[timeStepsPart2Index][0])):
            plotData[timeStepsPart2Index].append([])
        for dataPointIndex in range(len(simData[timeStepsPart2Index][0][0])):
            for popCountIndex in range(len(simData[timeStepsPart2Index][0])):
                plotDataSum = 0
                for trial in range(numTrials):
                    plotDataSum += simData[timeStepsPart2Index][trial][popCountIndex][dataPointIndex]
                plotData[timeStepsPart2Index][popCountIndex].append(plotDataSum / float(numTrials))
    ###
    def plotP5(title,timeStepInd):
        pylab.plot(range(len(plotData[timeStepInd][0])), plotData[timeStepInd][0], label = 'Total Population')
        labelPlot1 = capFirstChar(drug1) + '-Resistant Population'
        pylab.plot(range(len(plotData[timeStepInd][0])), plotData[timeStepInd][1], label = labelPlot1)
        labelPlot2 = capFirstChar(drug2) + '-Resistant Population'
        pylab.plot(range(len(plotData[timeStepInd][0])), plotData[timeStepInd][2], label = labelPlot2)
        labelPlot3 = 'Fuly-Resistant Population'
        pylab.plot(range(len(plotData[timeStepInd][0])), plotData[timeStepInd][3], label = labelPlot3)
        pylab.legend(loc='best')
        pylab.xlabel('Time Steps')
        pylab.ylabel('Number of Viruses')
        pylab.title(title)
        pylab.show()
    #Plot both cases:
    plotP5('Sim. of Pop. of Viruses in Patient w/ Drug Administered w/ '+str(timeStepLengthPart2[0])+' Time Steps Between Them',0)
    plotP5('Simulation of Population of Viruses in Patient w/ No Time In Between Them',1)
    

