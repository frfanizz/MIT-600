# -*- coding: utf-8 -*-
# Problem Set 6: Simulating robots
# Name:
# Collaborators:
# Time:

import math
import random

import ps6_visualize
import pylab

# === Provided classes

class Position(object):
    """
    A Position represents a location in a two-dimensional room.
    """
    def __init__(self, x, y):
        #Initializes a position with coordinates (x, y).
        self.x = x
        self.y = y
    def getX(self):
        return self.x
    def getY(self):
        return self.y
    def getNewPosition(self, angle, speed):
        """
        Computes and returns the new Position after a single clock-tick has
        passed, with this object as the current position, and with the
        specified angle and speed.
        Does NOT test whether the returned position fits inside the room.
        *angle: float representing angle in degrees, 0 <= angle < 360
        *speed: positive float representing speed
        **Returns: a Position object representing the new position.
        """
        old_x, old_y = self.getX(), self.getY()
        # Compute the change in position
        delta_y = speed * math.cos(math.radians(angle))
        delta_x = speed * math.sin(math.radians(angle))
        # Add that to the existing position
        new_x = old_x + delta_x
        new_y = old_y + delta_y
        return Position(new_x, new_y)

# === Problems 1

class RectangularRoom(object):
    """
    A RectangularRoom represents a rectangular region containing clean or dirty
    tiles.
    A room has a width and a height and contains (width * height) tiles. At any
    particular time, each of these tiles is either clean or dirty.
    """
    def __init__(self, width, height):
        """Initializes a rectangular room with the specified width and height.
        Initially, no tiles in the room have been cleaned."""
        assert type(width) == int and type(height) == int
        self.width = width
        self.height = height
        self.cleanTile = {}
        for m in range(self.width):
            for n in range(self.height):
                self.cleanTile[(m,n)] = False
         #tile status = { (x,y) = pos tuple : True = clean }
    
    def cleanTileAtPosition(self, pos):
        """
        *pos: a Position
        """
        #print int(pos.getX()),',',int(pos.getY())
        self.cleanTile[(int(pos.getX()),int(pos.getY()))] = True

    def isTileCleaned(self, m, n):
        """
        **returns: True if (m, n) is cleaned, False otherwise
        """
        assert type(m) == int and type(n) == int
        return self.cleanTile[(m,n)]
    
    def getNumTiles(self):
        #returns: an integer
        return self.width * self.height

    def getNumCleanedTiles(self):
        #returns: an integer
        numCleanedTiles = 0
        for m in range(self.width):
            for n in range(self.height):
                #print m,',',n
                if self.isTileCleaned(m,n):
                    numCleanedTiles += 1
        return numCleanedTiles

    def getRandomPosition(self):
        #returns: a Position object.
        return Position(self.width * random.random(),\
                        self.height * random.random())

    def isPositionInRoom(self, pos):
        """
        *pos: a Position object.
        **returns: True if pos is in the room, False otherwise.
        """
        return pos.getX() <= self.width and pos.getX() >= 0 and\
               pos.getY() <= self.height and pos.getY() >= 0

class Robot(object):
    """
    Represents a robot cleaning a particular room.
    At all times the robot has a particular position and direction in the room.
    The robot also has a fixed speed.
    Subclasses of Robot should provide movement strategies by implementing
    updatePositionAndClean(), which simulates a single time-step.
    """
    def __init__(self, room, speed):
        """
        Initializes a Robot with the given speed in the specified room. The
        robot initially has a random direction and a random position in the
        room. The robot cleans the tile it is on.
        *room:  a RectangularRoom object.
        *speed: a float (speed > 0)
        """
        self.room = room
        self.speed = speed
        self.direction = 360 * random.random()
        self.pos = self.room.getRandomPosition()
        self.room.cleanTileAtPosition(self.pos)

    def getRobotPosition(self):
        #returns: a Position object giving the robot's position.
        return self.pos
    
    def getRobotDirection(self):
        '''returns: an integer d giving the direction of the robot as an angle in
        degrees, 0 <= d < 360.'''
        return self.direction

    def setRobotPosition(self, position):
        """
        *position: a Position object.
        """
        self.pos = position

    def setRobotDirection(self, direction):
        """
        *direction: integer representing an angle in degrees
        """
        self.direction = direction

    def updatePositionAndClean(self):
        """
        Simulate the raise passage of a single time-step.
        Move the robot to a new position and mark the tile it is on as having
        been cleaned.
        """
        if self.room.isPositionInRoom(self.pos.getNewPosition(self.direction, self.speed)):
            self.setRobotPosition(self.pos.getNewPosition(self.direction, self.speed))
        else:
            self.setRobotDirection(360*random.random())
        self.room.cleanTileAtPosition(self.pos)

# === Problem 2
class StandardRobot(Robot):
    """
    A StandardRobot is a Robot with the standard movement strategy.
    At each time-step, a StandardRobot attempts to move in its current direction; when
    it hits a wall, it chooses a new direction randomly.
    """
    def updatePositionAndClean(self):
        """
        Simulate the passage of a single time-step.
        Move the robot to a new position and mark the tile it is on as having
        been cleaned.
        """
        Robot.updatePositionAndClean(self)

# === Problem 3

def zeros(num):
    zeroArray = []
    for n in range(num):
        zeroArray.append(0)
    return zeroArray

def average(arr):
    total = 0
    for entry in range(len(arr)):
        total += arr[entry]
    return float(total) / len(arr)

def runSimulation(num_robots, speed, width, height, min_coverage, num_trials,
                  robot_type = 'StandardRobot'):
    """
    Runs NUM_TRIALS trials of the simulation and returns the mean number of
    time-steps needed to clean the fraction MIN_COVERAGE of the room.
    The simulation is run with NUM_ROBOTS robots of type ROBOT_TYPE, each with
    speed SPEED, in a room of dimensions WIDTH x HEIGHT.
    *num_robots: an int (num_robots > 0)
    *speed: a float (speed > 0)
    *width: an int (width > 0)
    *height: an int (height > 0)
    *min_coverage: a float (0 <= min_coverage <= 1.0)
    *num_trials: an int (num_trials > 0)
    *robot_type: class of robot to be instantiated (e.g. Robot or
                RandomWalkRobot)
    """
    #Uncomment '###' comments to animate room cleaning
    stepsNeeded = zeros(num_trials) #for tracking steps
    #Run num_trials number of trials, and track steps req'd in each
    for trial in range(num_trials):
        ###anim = ps6_visualize.RobotVisualization(num_robots, width, height, 0.02)
        simRoom = RectangularRoom(width, height)
        
        #Create array of robots of type robot_type
        robotList = []
        if robot_type == 'RandomWalkRobot':
            for n in range(num_robots):
                robotList.append(RandomWalkRobot(simRoom, speed))
        else:
            for n in range(num_robots):
                robotList.append(StandardRobot(simRoom, speed))

        #Run and track steps until min_coverage is achieved
        coverage = float(simRoom.getNumCleanedTiles()) / simRoom.getNumTiles()
        while coverage < min_coverage:
            ###anim.update(simRoom, robotList)
            for n in range(num_robots):
                robotList[n].updatePositionAndClean()
            stepsNeeded[trial] += 1
            coverage = float(simRoom.getNumCleanedTiles()) / simRoom.getNumTiles()
    ###anim.done()
    return average(stepsNeeded)

def test1():
    return runSimulation(1, 1, 20, 20, 0.8, 1, 'std')

# === Problem 4
#
# 1) How long does it take to clean 80% of a 20×20 room with each of 1-10 robots?
#
# 2) How long does it take two robots to clean 80% of rooms with dimensions 
#	 20×20, 25×16, 40×10, 50×8, 80×5, and 100×4?

def showPlot1():
    meanTime = []
    for numRobots in range(1,11):
        meanTime.append(runSimulation(numRobots, 1, 20, 20, 0.8, 10, 'std'))
    pylab.plot(range(1,11),meanTime)
    pylab.xlabel('Number of Robots')
    pylab.ylabel('Number of Steps Needed (Time)')
    pylab.title('Time vs. Number of Robots')
    pylab.show()

def showPlot2():
    meanTime = []
    wLRatio = []
    for roomSize in [(20,20),(25,16),(40,10),(50,8),(80,5),(100,4)]:
        meanTime.append(runSimulation(2, 1, roomSize[0], roomSize[1], 0.8, 25, 'std'))
        wLRatio.append(float(roomSize[0]) / roomSize[1])
    pylab.plot(wLRatio,meanTime)
    pylab.xlabel('Room width/length ratio (Area=400)')
    pylab.ylabel('Number of Steps Needed (Time)')
    pylab.title('Time vs. Number of Robots')
    pylab.show()
    
# === Problem 5

class RandomWalkRobot(Robot):
    """
    A RandomWalkRobot is a robot with the "random walk" movement strategy: it
    chooses a new direction at random after each time-step.
    """
    def updatePositionAndClean(self):
        """
        Simulate the raise passage of a single time-step.
        Move the robot to a new position and mark the tile it is on as having
        been cleaned.
        """
        testPos = self.pos.getNewPosition(360*random.random(),self.speed)
        while not self.room.isPositionInRoom(testPos):
            testPos = self.pos.getNewPosition(360*random.random(),self.speed)
        #Does not use a step while running into walls
        self.setRobotPosition(testPos)
        self.room.cleanTileAtPosition(self.pos)


#runSimulation(2, 1, 20, 20, 0.8, 10, 'RandomWalkRobot')
# === Problem 6

# For the parameters tested below (cleaning 80% of a 20x20 square room),
# RandomWalkRobots take approximately twice as long to clean the same room as
# StandardRobots do.
def showPlot3():
    meanTimeStd = []
    meanTimeRng = []
    for numRobots in range(1,11):
        meanTimeStd.append(runSimulation(numRobots, 1, 20, 20, 0.8, 10, 'std'))
        meanTimeRng.append(runSimulation(numRobots, 1, 20, 20, 0.8, 10, 'RandomWalkRobot'))
    pylab.plot(range(1,11),meanTimeStd, label='Standard Movement')
    pylab.plot(range(1,11),meanTimeRng, label='Random Movement')
    pylab.legend(loc='upper right')
    pylab.xlabel('Number of Robots')
    pylab.ylabel('Number of Steps Needed (Time)')
    pylab.title('Time vs. Number of Robots')
    pylab.show()
